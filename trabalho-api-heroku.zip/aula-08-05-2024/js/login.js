document.addEventListener("DOMContentLoaded", function() {
    var body = document.querySelector("body");
    var singUpButton = document.querySelector("#singUp");
    var singInButton = document.querySelector("#singIn");

    body.className = "on-load";

    singUpButton.addEventListener("click", function() {
        body.className = "sing-up";
    });

    singInButton.addEventListener("click", function() {
        body.className = "sing-in";
    });

    function showError(message) {
        alert(message);
    }

    function redirectToWelcome() {
        window.location.href = "welcome.html";
    }

    function loadSwaggerSpec() {
        return fetch("https://api-umfg-programacao-iv-2024-291d5e9a4ec4.herokuapp.com/swagger/v1/swagger.json")
            .then(response => {
                if (!response.ok) {
                    throw new Error("Não foi possível carregar a especificação Swagger");
                }
                return response.json();
            })
            .catch(error => {
                console.error("Erro ao carregar o Swagger:", error);
                throw error;
            });
    }

    var signupForm = document.querySelector("#signup-form");
    signupForm.addEventListener("submit", function(event) {
        event.preventDefault();

        var email = document.querySelector("#signup-email").value;
        var password = document.querySelector("#signup-password").value;
        var confirmPassword = document.querySelector("#signup-confirm-password").value;

        if (password !== confirmPassword) {
            showError("As senhas não coincidem!");
            return;
        }

        if (!email || !password || !confirmPassword) {
            showError("Todos os campos são obrigatórios!");
            return;
        }

        loadSwaggerSpec()
            .then(swaggerSpec => {

                var signupEndpoint = swaggerSpec.paths['/v1/signup'];

                var requiredParameters = signupEndpoint.post.parameters.filter(param => param.required);
                console.log("Parâmetros obrigatórios para /v1/signup:", requiredParameters);

                return fetch("https://api-umfg-programacao-iv-2024-291d5e9a4ec4.herokuapp.com/v1/signup", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify({
                        email: email,
                        password: password,
                        confirmedPassword: confirmPassword
                    })
                });
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error("Erro ao cadastrar: " + response.statusText);
                }
                return response.json();
            })
            .then(data => {
                console.log("Signup response:", data);
                if (data.success) {
                    redirectToWelcome();
                } else {
                    showError("Erro ao cadastrar: " + data.message);
                }
            })
            .catch(error => {
                console.error("Signup error:", error);
                showError(error.message);
            });
    });

    var signinForm = document.querySelector("#signin-form");
    signinForm.addEventListener("submit", function(event) {
        event.preventDefault();

        var email = document.querySelector("#signin-email").value;
        var password = document.querySelector("#signin-password").value;

        if (!email || !password) {
            showError("Todos os campos são obrigatórios!");
            return;
        }

        loadSwaggerSpec()
            .then(swaggerSpec => {
        
                var signinEndpoint = swaggerSpec.paths['/v1/signin'];

                var requiredParameters = signinEndpoint.post.parameters.filter(param => param.required);
                console.log("Parâmetros obrigatórios para /v1/signin:", requiredParameters);

                return fetch("https://api-umfg-programacao-iv-2024-291d5e9a4ec4.herokuapp.com/v1/signin", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify({
                        email: email,
                        password: password
                    })
                });
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error("Erro ao acessar: " + response.statusText);
                }
                return response.json();
            })
            .then(data => {
                console.log("Signin response:", data);
                if (data.success) {
                    redirectToWelcome();
                } else {
                    showError("Erro ao acessar: " + data.message);
                }
            })
            .catch(error => {
                console.error("Signin error:", error);
                showError(error.message);
            });
    });
});
